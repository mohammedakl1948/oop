package farouq_oop_project;

import java.util.Arrays;

public class tasks {
	String[] task = new String[100];
	int completed = 0 , inserted = 0 , deleted = 0 , tasknumbers = 0 ;
	public tasks() {
		
	}
	public void Display() {
		for(int i  = 0 ; i < tasknumbers ; i++){
			System.out.println("Task "+(i+1)+" :\n"+task[i]);
		}
	}
	public void insertTask(String a) {
		task[inserted]=a;
		inserted++;
		tasknumbers++;
	}
	public void setToCompleted(int k) {
		for(int i = k ; i < tasknumbers ; i++) {
			task[k]=task[k+1];
		}
		completed++;
		tasknumbers--;
	}
	public void Delete(int a) {
		for(int i = a ; i < tasknumbers ; i++) {
			task[a]=task[a+1];
		}
		completed++;
		tasknumbers--;
	}
	@Override
	public String toString() {
		return "tasks [task=" + Arrays.toString(task) + ", completed=" + completed + ", inserted=" + inserted
				+ ", deleted=" + deleted + "]";
	}
	
}
