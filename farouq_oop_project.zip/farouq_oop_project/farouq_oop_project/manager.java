package farouq_oop_project;

public class manager extends employee {
	String user;
	String pass;
	public manager() {
		super();
		
	}
	public manager(String fname, String lname, String email, String phone , String user ,String pass) {
		super(fname, lname, email, phone);
		
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	@Override
	public String toString() {
		return "manager [user=" + user + ", pass=" + pass + ", fname=" + fname + ", lname=" + lname + ", email=" + email
				+ ", phone=" + phone + "]";
	}
	
	
	
	
	
	
}
