package farouq_oop_project;
import java.util.*;
public class main {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		tasks t = new tasks();
		admin e = new admin();
		e.setUser("admin");
		e.setPass("admin");
		
		manager m = new manager();
		m.setUser("manager");
		m.setPass("manager");
		int choice;
		do {
			int choice2;
			System.out.println("1.admin.");
			System.out.println("2.manager.");
			System.out.println("3.exit.");
			System.out.println("---------------------------------");
			choice = s.nextInt();
			if(choice==1) {
				System.out.println("Enter user:");
				String user = s.next();
				System.out.println("Enter pass:");
				String pass = s.next();
				System.out.println("---------------------------------");
				if(user.equals(e.getUser()) && pass.equals(e.getPass())) {
					do {
						
					System.out.println("---------------------------------");
					System.out.println("1.add task.");
					System.out.println("2.delete task.");
					System.out.println("3.Display.");
					System.out.println("4.Exit.");					
					choice2 = s.nextInt();
					switch(choice2) {
					case 1:
						System.out.println("Enter task:");
						t.insertTask(s.next());
						break;
					case 2:
						System.out.println("task number:");
						t.Delete(s.nextInt());
						break;
					case 3:
						t.Display();
						break;
					
					}
					System.out.println("---------------------------------");
					}while(choice2!=4);
				}else {
					System.out.println("wrong informations!");
				}
			}else if(choice==2) {
				System.out.println("Enter user:");
				String user = s.next();
				System.out.println("Enter pass:");
				String pass = s.next();
				System.out.println("---------------------------------");
				if(user.equals(m.getUser()) && pass.equals(m.getPass())) {
					do {
						
						System.out.println("---------------------------------");
						
						System.out.println("1.Display tasks.");
						System.out.println("2.set as completed.");
						System.out.println("3.Exit.");					
						choice2 = s.nextInt();
						switch(choice2) {
						case 1:
							t.Display();
							break;
						case 2:
							System.out.println("enter task number:");
							t.setToCompleted(s.nextInt());
							break;
						
						
						}
						System.out.println("---------------------------------");
						}while(choice2!=3);
				}else {
					System.out.println("wrong informations!");
				}
			}
		}while(choice!=3);

	}

}
