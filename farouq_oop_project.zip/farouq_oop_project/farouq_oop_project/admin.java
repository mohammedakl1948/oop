package farouq_oop_project;

public class admin extends employee {
	String user ,pass;

	public admin() {
		super();
	
	}

	public admin(String fname, String lname, String email, String phone) {
		super(fname, lname, email, phone);
		
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}
	
	
}
